import React, { Component } from 'react';
import './App.css';
import StateIter from './stateiter';

class App extends Component {
  state = {
    customerInfo: []
  }
  dataSet() {
    // This function to get the values from the text boxes and set the state
    var username = document.getElementById('userName').value;
    var email = document.getElementById('emailId').value;
    var mobile = document.getElementById('mobNumber').value;
    var address = document.getElementById('addressId').value;
    var purpose = document.getElementById('POVId').value;
    var dateOfVisit = document.getElementById('DOVId').value;

    var obj = {
      Name: username,
      EmailId: email,
      MobileNumber: mobile,
      Address: address,
      PurposeOfVisit: purpose,
      DateOFVisit: dateOfVisit
    }
    var { customerInfo } = this.state;
    customerInfo.push(obj);
    this.setState({ customerInfo });
  }

  OnDeletefxn(delIndex) {
    // This function to delete the data form the state
    console.log("deleted" + delIndex);
    var { customerInfo } = this.state;
    customerInfo.splice(delIndex, 1);
    console.log(customerInfo)
    this.setState({ customerInfo })
  }
  render() {
    return (
      <div className="App" className="container">
        <table className="table table-responsive">
          <thead>
            <tr><th>
              Customer Registration form
           </th></tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <input className="formcontrol" type="text" id="userName" placeholder="Username" />
              </td></tr>
            <tr>
              <td>
                <input type="text" id="emailId" placeholder="Email id" />
              </td></tr>
            <tr>
              <td>
                <input type="number" id="mobNumber" placeholder="Mobile Number" />
              </td></tr>

            <tr>
              <td>
                <input type="text" id="addressId" placeholder="Address" />
              </td></tr>

            <tr>
              <td>
                <input type="text" id="POVId" placeholder="Purpose of visit" />
              </td></tr>

            <tr>
              <td>
                <input type="date" id="DOVId" placeholder="date Of Visit" />
              </td></tr>

            <tr><td>
              <button className="btn btn-success" onClick={this.dataSet.bind(this)}>Log in</button>
            </td></tr>
          </tbody>
        </table>
        <br /><br /><br />
        <div>
          <StateIter datalist={this.state.customerInfo} handleDelete={this.OnDeletefxn.bind(this)} />
        </div>
      </div>
    );
  }
}

export default App;
