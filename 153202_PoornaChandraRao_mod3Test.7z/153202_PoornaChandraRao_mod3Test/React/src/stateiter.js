import React, { Component } from 'react';

class StateIter extends Component {
// this class is to render the customer info 
render() {
    if(this.props.datalist){
        var renData = this.props.datalist;
var renlist =   renData.map((i,index) => {
    return (<div key={index}>
       Name : {i.Name}<br/>
       Email Id : {i.EmailId}<br/>
       Mobile Number : {i.MobileNumber}<br/>
       Address : {i.Address}<br/>
       Description/Purpose : {i.PurposeOfVisit}<br/>
       Date of Visit : {i.DateOFVisit}
       <button className="btn btn-danger" onClick={this.props.handleDelete.bind(this,index)}>Delete</button>
       <br/>
    </div>)
});

return (

        <div>
            <h2>Customers visited list</h2>
            {renlist}</div>
    )
}

}
}

export default StateIter;