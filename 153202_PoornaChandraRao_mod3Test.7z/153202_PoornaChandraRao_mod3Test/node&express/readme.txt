Section 1

Using Browser 

1) type link  http://localhost:3000/display on Browser to view the data on console

2) type link  http://localhost:3000/range on Browser to view the data on console

3) using postman use link http://localhost:3000/update by using PUT method send any name to 
    update the existing name of the mobId = 1002

send  this data using postman

    {
        "mobName": "Samsung",
        }

4) using postman use link http://localhost:3000/mobile by using POST method
    to insert new mobile data
    with POST type and JSON format
    
    {
        "mobId": 1006,
        "mobName": "MI",
        "mobPrice": 10000.0
    }

