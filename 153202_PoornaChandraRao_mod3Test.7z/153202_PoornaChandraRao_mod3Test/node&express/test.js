var express = require('express');
var fs = require('fs');
var exp = express();
var parser = require('body-parser');

// importing data form the mobile.json file
var data = fs.readFileSync('./mobile.json');
data = JSON.parse(data);

//1) express get function to display all the data on the console
 
exp.get('/display',function(req,res){
    console.log("......Dispalying all data......");
    console.log(data);
    //sending Acknowledgement to the browser
    res.send("data displayed on console");
});


//2) express get function to display the data of mobiles having price range from 10000 to 50000 on the console
exp.get('/range',function(req,res){
    console.log("mobiles belonging to price range form 10000 to 50000");
    data.map(mydata =>{
        if(mydata.mobPrice>=10000 && mydata.mobPrice<=50000){
            console.log(mydata);
        }
    });
    res.send("data displayed on console");
});

/*3) express put function to update the name value using postman 
   with link  http://localhost:3000/update
    {
        "mobName": "Samsung",
    }
*/
exp.use(parser.json());
exp.put('/update',function(req,res){
     var sendBody = req.body;
    data.map(mydata =>{
        if(mydata.mobId === 1002){
            mydata.mobName = sendBody.mobName;
            fs.writeFileSync('./mobile.json',JSON.stringify(data));
            console.log(req.body);
        }
    });
    res.send("received");
});

/*
4) express post method inset new mobile data in the file
send this data with postman using link 'http://localhost:3000/mobile'
with POST type and JSON format
    {
        "mobId": 1006,
        "mobName": "MI",
        "mobPrice": 10000.0
    }

 See the result on the mobile.json   
*/
exp.post('/mobile',function(req,res){
    var sendBody = req.body;
    data.push(sendBody);
    fs.writeFileSync('./mobile.json',JSON.stringify(data));
    console.log("Mobile data added");
    res.send("data received");
})


exp.listen(3000,()=>{
    console.log("open browser.... to run");
});

